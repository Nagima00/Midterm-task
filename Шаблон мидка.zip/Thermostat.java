public class Thermostat implements SmartDevice {
    private String name;
    private double temperature;

    public Thermostat(String name) {
        this.name = name;
        this.temperature = 20.0;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
        System.out.println(name + " temperature set to " + temperature + "°C.");
    }

    @Override
    public void operate() {
        System.out.println(name + " is now operating.");
    }

    @Override
    public String toString() {
        return name + " (Thermostat) - " + temperature + "°C";
    }
}

