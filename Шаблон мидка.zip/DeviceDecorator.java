abstract class DeviceDecorator implements SmartDevice{
    protected SmartDevice decoratedDevice;

    public DeviceDecorator(SmartDevice device) {
        this.decoratedDevice = device;
    }

    public void operate() {
        decoratedDevice.operate();
    }
}
