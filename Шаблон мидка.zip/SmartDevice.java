interface SmartDevice {
    void operate();
}
