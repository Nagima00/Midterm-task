public class LegacyDoorLock {
    public void unlock() {
        System.out.println("Legacy Door Lock: Unlocked");
    }
}
