public class Light implements SmartDevice {
    private String name;
    private boolean isOn;

    public Light(String name) {
        this.name = name;
        this.isOn = false;
    }

    @Override
    public void operate() {
        isOn = true;
        System.out.println(name + " light is turned on.");
    }

    public void turnOff() {
        isOn = false;
        System.out.println(name + " light is turned off.");
    }

    @Override
    public String toString() {
        return name + " (Light) - " + (isOn ? "ON" : "OFF");
    }
}

