public class LoggingDecorator extends DeviceDecorator{
    public LoggingDecorator(SmartDevice device) {
        super(device);
    }

    @Override
    public void operate() {
        System.out.println("[LOG] Operation started");
        super.operate();
        System.out.println("[LOG] Operation completed");
    }
}
