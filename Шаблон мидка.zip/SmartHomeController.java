import java.util.ArrayList;
import java.util.List;

public class SmartHomeController {
    private final List<SmartDevice> devices;

    public SmartHomeController() {
        this.devices = new ArrayList<>();
    }

    public void addDevice(SmartDevice device) {
        devices.add(device);
    }

    public void turnAllLightsOn() {
        for (SmartDevice device : devices) {
            if (device instanceof Light) {
                device.operate();
            }
        }
        System.out.println("✅ All lights have been turned ON.");
    }

    public void turnAllLightsOff() {
        for (SmartDevice device : devices) {
            if (device instanceof Light) {
                ((Light) device).turnOff();
            }
        }
        System.out.println("⛔ All lights have been turned OFF.");
    }

    public void setGlobalTemperature(double temperature) {
        for (SmartDevice device : devices) {
            if (device instanceof Thermostat) {
                ((Thermostat) device).setTemperature(temperature);
            }
        }
        System.out.println("🌡 Temperature set to " + temperature + "°C for all thermostats.");
    }

    public void getSystemStatusReport() {
        System.out.println("\n📊 Smart Home Status Report:");
        for (SmartDevice device : devices) {
            System.out.println("   - " + device);
        }
    }
}
