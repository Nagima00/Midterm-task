public class SmartHomeSystem {
    public static void main(String[] args) {
        SmartHomeController controller = new SmartHomeController();

        Light light1 = new Light("Living Room Light");
        Light light2 = new Light("Kitchen Light");
        Thermostat thermostat = new Thermostat("Main Thermostat");

        controller.addDevice(light1);
        controller.addDevice(light2);
        controller.addDevice(thermostat);

        controller.turnAllLightsOn();
        controller.setGlobalTemperature(22.5);
        controller.getSystemStatusReport();
        controller.turnAllLightsOff();
    }
}
