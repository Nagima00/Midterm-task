public class DoorLockAdapter implements SmartDevice{
    private LegacyDoorLock legacyLock;

    public DoorLockAdapter(LegacyDoorLock legacyLock) {
        this.legacyLock = legacyLock;
    }

    @Override
    public void operate() {
        legacyLock.unlock();
    }
}
